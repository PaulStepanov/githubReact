import React, { Component } from "react";
import PropTypes from "prop-types";
import Title from "./components/title";
import Tabs from "./components/tabs";

import style from "./style.sass";

const mockProps = {
  userName: "Test",
  repoName: "Project",
  stars: 2,
  forks: 1,
  unwatched: 0
};

const tabs = [ //move to constants
  {
    icon: "code",
    text: "Code",
    showCount: false
  },
];

class index extends Component {
  render() {
    const { userName, repoName, stars, forks, unwatched } = mockProps; //this.props

    return (
      <div className={style.Header}>
        <div className={style.headerContent}>
          <Title {...mockProps} />
          <Tabs />
        </div>
      </div>
    );
  }
}

index.propTypes = {
  userName: PropTypes.string,
  repoName: PropTypes.string,
  stars: PropTypes.number,
  forks: PropTypes.number,
  unwatched: PropTypes.number
};

export default index;
