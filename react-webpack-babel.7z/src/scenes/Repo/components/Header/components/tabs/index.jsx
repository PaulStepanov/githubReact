import React from "react";
import PropTypes from "prop-types";
import { Tabs } from "antd";

import style from "./style.sass";

const { TabPane } = Tabs;

const index = ({ tabs }) => (
  <div className={style.TabsContainer}>
    <Tabs type="card">
      {tabs.map((tab, i) => <TabPane tab={tab.text} key={i} />)}
    </Tabs>
  </div>
);

index.propTypes = {
  tabs: PropTypes.arrayOf(
    PropTypes.shape({
      icon: PropTypes.string.isRequired,
      text: PropTypes.string.isRequired,
      showCount: PropTypes.bool,
      count: PropTypes.number
    })
  )
};

export default index;
