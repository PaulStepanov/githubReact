import React, { Component } from 'react';
import Header from './components/Header';

class index extends Component {
    render() {
        return (
            <div>
                <Header></Header>
            </div>
        );
    }
}

export default index;